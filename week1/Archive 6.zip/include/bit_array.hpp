#include <vector>
#include <iostream>
#include <stdexcept>
#include <cmath>

namespace pfp {

class BitArray {
public:
    std::vector<uint64_t> bits;

    BitArray(size_t n) { bits.resize((n + 63) / 64); }

    inline bool get(size_t pos) const {
        size_t index = pos >> 6; // Equivalent to pos / 64
        size_t bit = pos & 63; // Equivalent to pos % 64
        if (pos >= bits.size() << 6) {
            throw std::out_of_range("Bit position out of range.");
        }
        return (bits[index] >> bit) & 1;
    }

    inline void set(size_t pos, bool value) {
        size_t index = pos >> 6;
        size_t bit = pos & 63;
        if (pos >= bits.size() << 6) {
            throw std::out_of_range("Bit position out of range.");
        }
        if (value) {
            bits[index] |= 1ULL << bit;
        } else {
            bits[index] &= ~(1ULL << bit);
        }
    }
};

} // namespace pfp
