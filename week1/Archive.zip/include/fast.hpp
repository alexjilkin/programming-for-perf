#include <bitset>
#include <climits> 

#pragma once

namespace pfp {

class fast {
  static const int MAX_SIZE = 1000000; 
  std::bitset<MAX_SIZE> bitset;

public:
  fast() {}

  void insert(int val) {
    if (val >= 0 && val < MAX_SIZE) {
      bitset.set(val);
    }
    // Else, you might want to handle the error or ignore the insert
  }

  int count(int val) {
    if (val >= 0 && val < MAX_SIZE) {
      return bitset.test(val) ? 1 : 0;
    }
    return 0; // Value is out of range, so it cannot be in the set
  }
};

}
