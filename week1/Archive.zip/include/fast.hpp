#pragma once

#include <vector>
#include <algorithm>
#include "bit_array.hpp"
#include <cmath>

namespace pfp {

template <class dtype>
class fast {
  pfp::BitArray ba;

private:
  uint64_t max = pow(2, 20) - 1;
public:
  // Constructor initializes the BitArray with a fixed size
  fast() : ba(pow(2, 20) - 1) {}

  // Insert value into BitArray
  void insert(dtype pos) {
    ba.set(pos & max, true);
  }

  // Count occurrences of val (in this context, checks if val is set)
  int count(dtype pos) {
    return ba.get(pos & max); // Assuming get returns an integer, 0 or 1
  }
};

} // namespace pfp
